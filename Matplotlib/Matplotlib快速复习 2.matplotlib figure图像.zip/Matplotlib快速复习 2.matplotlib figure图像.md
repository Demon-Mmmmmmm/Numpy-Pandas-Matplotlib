

```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
x = np.linspace(-1, 1, 100)
y1 = 2 * x + 1
y2 = x ** 2

plt.figure()
plt.plot(x, y1)

plt.figure()
plt.plot(x, y2)
plt.show()
```


![png](output_1_0.png)



![png](output_1_1.png)



```python
x = np.linspace(-1, 1, 100)
y1 = 2 * x + 1
y2 = x ** 2

plt.figure()
plt.plot(x, y1)

plt.figure(figsize = (8, 5)) #多个figure就是窗口
plt.plot(x, y2)
plt.show()
```


![png](output_2_0.png)



![png](output_2_1.png)



```python
plt.plot(x, y1, color = 'red', linewidth = 1.0, linestyle = '--') #参数设置可以比较多，--为虚线
plt.plot(x, y2, color = 'blue', linewidth = 5.0, linestyle = '-') #-为实线
plt.show()
```


![png](output_3_0.png)



```python

```
