

```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
plt.scatter(np.arange(5),np.arange(5))
plt.show()
```


![png](output_1_0.png)



```python
x = np.random.normal(0, 1, 500)
y = np.random.normal(0, 1, 500)
plt.scatter(x, y, s = 50, c = 'b', alpha = 0.5)

plt.xlim((-2, 2))
plt.ylim((-2, 2))

plt.xticks(())
plt.yticks(())
plt.show()
```


![png](output_2_0.png)



```python

```
