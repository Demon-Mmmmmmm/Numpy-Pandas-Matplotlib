

```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
plt.figure()
plt.subplot(2,2,1) #两行两列的第一个位置
plt.plot([0,1], [0,1])

plt.subplot(2,2,2) #两行两列的第二个位置
plt.plot([0,1], [0,1])

plt.subplot(2,2,3) #两行两列的第三个位置
plt.plot([0,1], [0,1])

plt.subplot(2,2,4) #两行两列的第四个位置
plt.plot([0,1], [0,1])

#plt.subplot(2,2,5) #两行两列的第五个位置？不，这是错的，两行两列只有四个，只能大于等于1，小于等于4
#plt.plot([0,1], [0,1])

plt.show()
```


![png](output_1_0.png)



```python
plt.figure()
plt.subplot(2,1,1) #两行一列的第一个位置
plt.plot([0,1], [0,1])

plt.subplot(2,3,4) 
#两行三列的第四个位置，这里特别注意，即使上面是第一个位置，但这句已经由两行一列变成两行三列，所以相当于上面占了3个位置，这里要从第四开始算起
plt.plot([0,1], [0,1])

plt.subplot(2,3,5)
plt.plot([0,1], [0,1])

plt.subplot(2,3,6)
plt.plot([0,1], [0,1])

plt.show()
```


![png](output_2_0.png)

