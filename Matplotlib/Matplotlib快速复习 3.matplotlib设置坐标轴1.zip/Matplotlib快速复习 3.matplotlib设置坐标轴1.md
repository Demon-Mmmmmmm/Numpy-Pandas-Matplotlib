

```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
x = np.linspace(-3, 3, 100)
y1 = 2 * x + 1
y2 = x ** 2

#xy范围
plt.xlim((-1, 2))
plt.ylim((-2, 3))

#xy描述
plt.xlabel('I AM X')
plt.ylabel('I AM Y')

plt.plot(x, y1, color = 'red', linewidth = 1.0, linestyle = '--') #参数设置可以比较多，--为虚线
plt.plot(x, y2, color = 'blue', linewidth = 5.0, linestyle = '-') #-为实线
plt.show()
```


![png](output_1_0.png)



```python
new_ticks = np.linspace(-2, 2, 11)
print(new_ticks)
```

    [-2.  -1.6 -1.2 -0.8 -0.4  0.   0.4  0.8  1.2  1.6  2. ]



```python
x = np.linspace(-3, 3, 100)
y1 = 2 * x + 1
y2 = x ** 2

#xy范围
plt.xlim((-1, 2))
plt.ylim((-2, 3))

#xy描述
plt.xlabel('I AM X')
plt.ylabel('I AM Y')

plt.plot(x, y1, color = 'red', linewidth = 1.0, linestyle = '--') #参数设置可以比较多，--为虚线
plt.plot(x, y2, color = 'blue', linewidth = 5.0, linestyle = '-') #-为实线
plt.xticks(new_ticks)
plt.yticks([-1, 0, 1, 2, 3],
           ['level1', 'level2', 'level3', 'level4', 'level5'])
plt.show()
```


![png](output_3_0.png)



```python

```
