

```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
x = np.arange(10)
y = 2 ** x + 10
plt.bar(x, y)
plt.show()
```


![png](output_1_0.png)



```python
x = np.arange(10)
y = 2 ** x + 10
plt.bar(x, -y)
plt.show()
```


![png](output_2_0.png)



```python
x = np.arange(10)
y = 2 ** x + 10
plt.bar(-x, y)
plt.show()
```


![png](output_3_0.png)



```python
x = np.arange(10)
y = 2 ** x + 10
plt.bar(-x, -y)
plt.show()
```


![png](output_4_0.png)



```python
x = np.arange(10)
y = 2 ** x + 10
plt.bar(x, y, facecolor = '#9999ff', edgecolor = 'white')
plt.show()
```


![png](output_5_0.png)



```python
x = np.arange(10)
y = 2 ** x + 10
plt.bar(x, y, facecolor = '#9999ff', edgecolor = 'white')
for x,y in zip(x, y):
    plt.text(x, y, '%.2f' % y, ha = 'center', va = 'bottom') #

plt.show()
```


![png](output_6_0.png)



```python

```
