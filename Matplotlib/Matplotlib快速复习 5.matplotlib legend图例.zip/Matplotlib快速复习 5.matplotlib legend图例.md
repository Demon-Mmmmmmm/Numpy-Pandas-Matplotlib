

```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
x = np.linspace(-3, 3, 100)
y1 = 2 * x + 1
y2 = x ** 2

#xy范围
plt.xlim((-1, 2))
plt.ylim((-2, 3))

#xy描述
plt.xlabel('I AM X')
plt.ylabel('I AM Y')

new_ticks = np.linspace(-2, 2, 11)
print(new_ticks)


#l1,l2必须加逗号，不然会报错，设置图例是以下三行代码
l1, = plt.plot(x, y1, color = 'red', linewidth = 1.0, linestyle = '--') #参数设置可以比较多，--为虚线
l2, = plt.plot(x, y2, color = 'blue', linewidth = 5.0, linestyle = '-') #-为实线
plt.legend(handles = [l1,l2], labels = ['test1', 'test2'], loc = 'best')

plt.xticks(new_ticks)
plt.yticks([-1, 0, 1, 2, 3],
           ['level1', 'level2', 'level3', 'level4', 'level5'])

#gca: get current axis
ax = plt.gca()
#把右边和上边的边框去掉
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
#设置bottom对应到0点
#设置left对应到0点
#ax.xaxis.set_ticks_position('bottom')
#ax.yaxis.set_ticks_position('left')

ax.spines['bottom'].set_position(('data', 0))
ax.spines['left'].set_position(('data', 0))
plt.show()
```

    [-2.  -1.6 -1.2 -0.8 -0.4  0.   0.4  0.8  1.2  1.6  2. ]



![png](output_1_1.png)



```python

```
