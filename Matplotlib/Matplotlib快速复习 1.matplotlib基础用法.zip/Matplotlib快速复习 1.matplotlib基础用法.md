

```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
x = np.linspace(-1, 1, 100) #从（-1， 1）生成100个点
y = 2 * x + 1
plt.plot(x, y) #
plt.show()
```


![png](output_1_0.png)



```python

```
