

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
data = pd.Series(np.random.randn(1000), index = np.arange(1000))
data = data.cumsum()
data.plot()
plt.show()
```


![png](output_1_0.png)



```python
data = pd.DataFrame(np.random.randn(1000, 4), index = np.arange(1000), columns = ['A', 'B', 'C', 'D'])
data = data.cumsum()
print(data.head())
```

              A         B         C         D
    0 -1.011897 -0.235211 -2.420510  1.238271
    1 -1.477754 -1.966545 -2.323233  5.908834
    2 -0.747672 -2.539343 -1.500558  5.000472
    3 -1.981201 -0.931522 -3.050500  3.117508
    4 -1.545389 -1.529575 -3.088517  3.316093



```python
data.plot()
plt.show()
```


![png](output_3_0.png)



```python
ax = data.plot.scatter(x = 'A', y = 'B', color = 'Blue', label = 'class 1')
data.plot.scatter(x = 'A', y = 'C', color = 'Yellow', label = 'class 2', ax = ax)
plt.show()
```


![png](output_4_0.png)

